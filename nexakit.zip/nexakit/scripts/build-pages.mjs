// node scripts/build-pages.mjs  -> /tools/<id>.html for EVERY tool + sitemap.xml + robots.txt (programmatic SEO)
import fs from 'fs'; import { TOOLS, CATS } from '../js/registry.js'; import { CONFIG } from '../js/config.js';
const base = fs.readFileSync('index.html','utf8'); fs.mkdirSync('tools',{recursive:true});
for (const t of TOOLS) {
  const title = `${t.name} — Free Online Tool | NexaKit`, desc = `Free ${t.name} (${CATS[t.cat]}). Fast, private, works offline. No sign-up needed.`;
  const ld = `<script type="application/ld+json">${JSON.stringify({'@context':'https://schema.org','@type':'WebApplication',name:t.name,applicationCategory:'UtilitiesApplication',offers:{'@type':'Offer',price:'0',priceCurrency:'USD'}})}</script>`;
  fs.writeFileSync(`tools/${t.id}.html`, base
    .replace(/<title>.*?<\/title>/, `<title>${title}</title>`)
    .replace(/(<meta name="description" content=")[^"]*/, `$1${desc}`)
    .replace(/(rel="canonical" href=")[^"]*/, `$1${CONFIG.SITE_URL}/tools/${t.id}.html`)
    .replace(/(og:title" content=")[^"]*/, `$1${title}`)
    .replace('</head>', `${ld}<script>location.hash='${t.id}'</script></head>`));
}
fs.writeFileSync('sitemap.xml',`<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${['',...TOOLS.map(t=>`tools/${t.id}.html`)].map(p=>`<url><loc>${CONFIG.SITE_URL}/${p}</loc></url>`).join('')}</urlset>`);
fs.writeFileSync('robots.txt',`User-agent: *\nAllow: /\nSitemap: ${CONFIG.SITE_URL}/sitemap.xml\n`);
console.log('built', TOOLS.length, 'tool pages');
